---
up:
  - "[[Things]]"
in:
  - "[[Collections]]"
tags:
  - "#map/view"
created: 2023-11-26
---
This note collects all notes where the `in` property says `Concepts`.

> [!aperture]+ ## Concepts by rank and what they say
> ```dataview
> TABLE WITHOUT ID
> 	file.link as Concept,
> 	says as Says,
> 	rank as Rank
> WHERE
> 	contains(in,this.file.link) and
> 	!contains(file.name, "Template")
> SORT rank desc, file.link asc
> ```
