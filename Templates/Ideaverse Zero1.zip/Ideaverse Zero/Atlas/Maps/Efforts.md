---
up:
  - "[[Home Pro]]"
in:
  - "[[Collections]]"
created: 2023-08-19
tags:
  - map/view
---
Keep your priorities in order. Quickly adjust your bandwidth as needed. 

> [!Box]+ ### 🔥 On
> ``` dataview
> TABLE WITHOUT ID
> file.link as "",
>  rank as "Rank"
> FROM "Efforts/On"
> SORT rank desc
> ```


> [!Box]+ ### ♻️ Ongoing
> ``` dataview
> TABLE WITHOUT ID
> file.link as "",
> rank as "Rank"
> FROM "Efforts/Ongoing"
> SORT rank desc
> ```


> [!Box]+ ### 〰️ Simmering
> Efforts can easily move from `on` to `simmering` in the background.
>
> ``` dataview
> TABLE WITHOUT ID
> file.link as "",
> rank as "Rank"
> FROM "Efforts/Simmering"
> SORT rank desc
> ```

---

> [!faq]+ Learn more about Efforts
> - [[The big differences between efforts and projects]]
> - [[The Four Intensities of Efforts]]
> - [[Why Efforts are Liberating]]
> - [[How ideas and efforts play nicely together]]
>   
>   ![[robert-mccall-black-hole-concept-art copy.jpg]]

Back to [[Home Pro]].
