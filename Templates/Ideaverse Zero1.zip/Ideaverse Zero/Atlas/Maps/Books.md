---
in:
  - "[[Collections]]"
related:
  - "[[Books]]"
  - "[[Movies]]"
  - "[[Series]]"
tags:
  - "#map/view"
created: 2022-01-01
cssclasses:
  - wide-page
---
This note collects all notes where the `in` property says `Books`.

> [!book]+ ## Books
> Books sorted by `Ratings` & `YearXP`
> ```dataview
> TABLE WITHOUT ID
> 	year as Year,
> 	"![|60](" + image + ")" as Cover,
> 	file.link as Title,
> 	join(list(by)) as Author,
> 	yearXP as YearXP,
> 	rating as Rating
> WHERE
> 	contains(in,this.file.link) and
> 	!contains(file.name, "Template")
> SORT rating desc, year asc
> ```


# Extra
These are "works in progress" but they should give you some ideas for your own book groups and bookshelves. 

> [!book]- Books by Type, Category, Group
> ```dataview
> TABLE WITHOUT ID
> 	year as Year,
> 	file.link as Title,
> 	bookCategory as Category,
> 	join(list(bookGroup)) as Group,
> 	join(list(bookLCSH)) as LCSH,
> 	bookType as Type
> WHERE
> 	contains(in,this.file.link) and
> 	!contains(file.name, "Template")
> SORT bookCategory, desc, year desc
> ```

> [!book]- Books by Status as "Reading"
> ```dataview
> TABLE WITHOUT ID
> 	year as Year,
> 	"![|60](" + image + ")" as Cover,
> 	file.link as Title,
> 	bookCategory as Category,
> 	bookType as Type
> WHERE
> 	contains(in,this.file.link) and
> 	bookStatus = "reading" and
> 	!contains(file.name, "Template")
> SORT bookCategory, desc, year desc
> ```

> [!book]- By Tag (deprecated)
> Slowly swap tags for Book metadata.
> ```dataview
> TABLE WITHOUT ID
>  year as "Year",
>  file.link as Book,
>  bookGroup as Group
>  
> FROM #source/book and -#on/readme 
> 
> SORT file.name asc
> ```